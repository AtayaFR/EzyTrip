package com.example.ezytrip;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button buttonLihat1;
    private Button wantMoreButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonLihat1 = findViewById(R.id.buttonLihat1);
        wantMoreButton = findViewById(R.id.wantMoreButton);

        buttonLihat1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an implicit intent to start Google Maps
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=Sate Kambing-Buntel Pak H.Kasdi"));

                // Start the Google Maps activity
                startActivity(intent);
            }
        });

        wantMoreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create an explicit intent to start MainActivity2
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);

                // Start MainActivity2
                startActivity(intent);
            }
        });
    }
}